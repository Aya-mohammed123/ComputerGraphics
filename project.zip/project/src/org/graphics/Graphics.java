/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.graphics;
import java.lang.Math;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.util.texture.Texture;
import static java.lang.Math.cos;
import static java.lang.Math.sin;
import org.resources.ImageResource;

/**
 *
 * @author Mass
 */
public class Graphics {
    public static GL2 gl=EventListener.gl;
    private static float red=1;
    private static float blue=1;
    private static float green=1;
    private static float alpha=1;
    private static float rotation=70;
    public static void setRotation(float r)
    {
        rotation=r;
    }
    public static void setColor(float r,float b,float g ,float a){
        
        red=Math.max(0, Math.min(1,r));
        green=Math.max(0, Math.min(1,g));
        blue=Math.max(0, Math.min(1,b));
        alpha=Math.max(0, Math.min(1,a));
    }
    public static void fillRect(float x,float y,float width,float height){
        
        gl.glColor4f(red,green,blue,alpha); 
        gl.glBegin(GL2.GL_QUADS);
          gl.glVertex2f(x,y);
          gl.glVertex2f(x+width,y);
          gl.glVertex2f(x+width,y+height);
          gl.glVertex2f(x,y+height);
        gl.glEnd();   
    }
//      public static void fillCircle(ImageResource image, float x, float y, float radius){
//          Texture tex=image.getTexture();
//        if (tex!=null){
//            gl.glBindTexture(GL2.GL_TEXTURE_2D, tex.getTextureObject());
//        }
//        double theta;
//        gl.glColor4f(red,green,blue,alpha); 
//        gl.glBegin(GL2.GL_POLYGON);
//         for (int i = 0; i < 360; i++) {
//            theta = i * Math.PI / 180;// Convert degrees to radians
//             gl.glVertex2d(x+radius*cos(theta),y+radius* sin(theta));
//        }
//        gl.glEnd();  
//        gl.glFlush();
//            gl.glBindTexture(GL2.GL_TEXTURE_2D, 0);
//          
//    }
    
    public static void fillCircle(ImageResource image, float x, float y, float radius){
    Texture tex=image.getTexture();
    if (tex!=null){
        gl.glBindTexture(GL2.GL_TEXTURE_2D, tex.getTextureObject());
    }
    double theta;
    gl.glColor4f(red,green,blue,alpha); 
    gl.glBegin(GL2.GL_POLYGON);
     for (int i = 0; i < 360; i++) {
        theta = i * Math.PI / 180;// Convert degrees to radians
        double vx = x + radius * Math.cos(theta);
        double vy = y + radius * Math.sin(theta);
        double u = (vx - x) / (2 * radius); // Mapping x to [0, 1]
        double v = (vy - y) / (2 * radius); // Mapping y to [0, 1]
        gl.glTexCoord2d(u, v);
        gl.glVertex2d(vx, vy);
    }
    gl.glEnd();  
    gl.glFlush();
    gl.glBindTexture(GL2.GL_TEXTURE_2D, 0);      
}

      public static void fillSmallCircle( float x, float y, float radius){
    
    double theta;
    gl.glColor4f(red,green,blue,alpha); 
    gl.glBegin(GL2.GL_POLYGON);
     for (int i = 0; i < 360; i++) {
        theta = i * Math.PI / 180;// Convert degrees to radians
        double vx = x + radius * Math.cos(theta);
        double vy = y + radius * Math.sin(theta);
        double u = (vx - x) / (2 * radius); // Mapping x to [0, 1]
        double v = (vy - y) / (2 * radius); // Mapping y to [0, 1]
        gl.glTexCoord2d(u, v);
        gl.glVertex2d(vx, vy);
    }
    gl.glEnd();  
    gl.glFlush();     
}
    
    
    
    
    public static void drawImage(ImageResource image ,float x,float y,float width,float height){
        Texture tex=image.getTexture();
        if (tex!=null){
            gl.glBindTexture(GL2.GL_TEXTURE_2D, tex.getTextureObject());
        }
        gl.glTranslatef(x,y,0);
        gl.glRotatef(rotation, 0, 0, 1);
            gl.glColor4f(red,green,blue,alpha); 
            gl.glBegin(GL2.GL_QUADS);
               gl.glTexCoord2f(0, 1);
               gl.glVertex2f(x,y);
               gl.glTexCoord2f(1, 1);
               gl.glVertex2f(x+width,y);
               gl.glTexCoord2f(1, 0);
               gl.glVertex2f(x+width,y+height);
               gl.glTexCoord2f(0, 0);
               gl.glVertex2f(x,y+height);
            gl.glEnd(); 
            gl.glFlush();
            gl.glBindTexture(GL2.GL_TEXTURE_2D, 0);
           gl.glRotatef(-rotation, 0, 0, 1);
          gl.glTranslatef(-x,-y,0);
    }
}
