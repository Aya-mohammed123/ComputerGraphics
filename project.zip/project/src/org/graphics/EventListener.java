/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.graphics;

import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLEventListener;
import org.resources.ImageResource;

/**
 *
 * @author Mass
 */
public class EventListener implements GLEventListener {
    public static float x=-5;
    public static String path="/res/face.jpg";//SiamjustAGirl.jpg"
    public static String pathears="/res/ears.jpg";
    public static GL2 gl=null;
    public static int unitTall=0;
    public static ImageResource image=null;
    public static float dir1=250;
    public static float dir2=250;
//    public static float dir1=0;
//    public static float dir2=0;
    public static float x_dir=0;
    public static float y_dir=0;
//    public static float apprx1=450;
//    public static float apprx2=50;
//    public static float appry=450;
    public static float apprx1=dir1+200;
    public static float apprx2=dir1-200;
    public static float appry=dir2+200;
    public static boolean isModeChanged = false;

    @Override
    public void init(GLAutoDrawable glad) {
          gl=glad.getGL().getGL2();
          gl.glEnable(GL2.GL_TEXTURE_2D);
          image=new ImageResource(path);
    }
    @Override
    public void dispose(GLAutoDrawable glad) {
    
    }
    @Override
public void display(GLAutoDrawable glad) {
    gl = glad.getGL().getGL2();
    gl.glClear(GL2.GL_COLOR_BUFFER_BIT);
    gl.glClearColor(0f, 0.5f, 0.5f, 1);
//gl.glClearColor(.67f, 0f, 0.5f, 1);
     Graphics.setColor(0.6f, 0.8f, 0f, 1);
//    Graphics.setColor(0.678f, 0.847f, 0.902f, 1);
     Graphics.setColor(1f, 1f, 1f, 1);
//    Graphics.drawImage(image, dir1, dir2, 2f, 2f);
    //  Graphics.fillRect(dir1, dir2, 2f, 2f);
//      Graphics.fillCircle(image,250,250,70);
//      Graphics.fillCircle(image,apprx1,appry,20);
//      Graphics.fillCircle(image,apprx2,appry,20);

        Graphics.fillCircle(image,dir1,dir2,70);
        Graphics.fillSmallCircle(apprx1,appry,20);
        Graphics.fillSmallCircle(apprx2,appry,20);


    Graphics.setRotation(x);

    // Keyboard
    dir1 += x_dir;
    dir2 += y_dir;
    if (dir1 >500) {
        dir1 =0;
    } else if (dir1 <0) {
        dir1 = 500;
    }

    if (dir2 > 500) {
        dir2 = 0;
    } else if (dir2 < 0) {
        dir2 =500;
    }  
    
     if (apprx1 > 500) {
        apprx1 = 0;
    } else if (apprx1 < 0) {
        apprx1 =500;
    } 
     if (apprx2 > 500) {
        apprx2 = 0;
    } else if (apprx2 < 0) {
        apprx2 =500;
    } 
     
     
     
     
     if (appry > 500) {
        appry = 0;
    } else if (appry < 0) {
        appry =500;
    } 
//    if (dir1 > Render.unitWide / 2) {
//        dir1 = -Render.unitWide / 2;
//    } else if (dir1 < -Render.unitWide / 2) {
//        dir1 = Render.unitWide / 2;
//    }
//
//    if (dir2 > EventListener.unitTall / 2) {
//        dir2 = -EventListener.unitTall / 2;
//    } else if (dir2 < -EventListener.unitTall / 2) {
//        dir2 = EventListener.unitTall / 2;
//    }
    //        //input mouse 
        
//        if (x>5)
//      {
//          x= -5;
//      }
//        x+=0.1f;
}


    @Override
     public void reshape(GLAutoDrawable glad, int x, int y, int width, int height)
    {
      gl=glad.getGL().getGL2();
      gl.glMatrixMode(GL2.GL_PROJECTION);
      gl.glLoadIdentity();
      unitTall=Render.getWindowHeight()/(Render.getWindowWidth()/Render.unitWide);
     // gl.glOrtho(-Render.unitWide/2, Render.unitWide/2, -unitTall/2, unitTall/2, -1, 1);
     gl.glOrtho(0,500,0,500,-1,1);
     gl.glMatrixMode(GL2.GL_MODELVIEW);
       
    }
    
}
