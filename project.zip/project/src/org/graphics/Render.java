/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.graphics;

import com.jogamp.newt.opengl.GLWindow;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLProfile;
import com.jogamp.opengl.util.FPSAnimator;
import org.input.KeyInput;
import org.input.MouseInput;

/**
 *
 * @author Mass
 */
public class Render {
    
    public static GLWindow window=null;
    public static int windowWidth=660;
    public static int windowHeight=400;
    public static int unitWide=10;
    
    public static int getWindowWidth()
    {
        return window.getWidth();
    }
    
    public static int getWindowHeight()
    {
        return window.getHeight();
    }
    public static GLProfile getProfile()
    {
        return window.getGLProfile();
    }
    public static void init(){
        
         GLProfile.initSingleton();
         GLProfile profile=GLProfile.get(GLProfile.GL2) ;
         GLCapabilities caps=new GLCapabilities (profile);
         window=GLWindow.create(caps);
         window.setSize(windowWidth,windowHeight);
         window.setVisible(true);
         window.setFullscreen(false);
         window.setResizable(true);
         window.addGLEventListener(new EventListener());
         window.addMouseListener(new MouseInput());
         window.addKeyListener(new KeyInput());
         FPSAnimator animator=new FPSAnimator(window,60);
         animator.start();    
     }
    public static void main(String []args){
             init();
             while(window.isVisible()) {
                  // Continue running as long as the window is visible
             }
             System.exit(0);
          }
}
