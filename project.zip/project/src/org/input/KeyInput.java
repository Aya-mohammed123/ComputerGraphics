/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.input;

import com.jogamp.newt.event.KeyEvent;
import com.jogamp.newt.event.KeyListener;
import org.graphics.EventListener;

/**
 *
 * @author Mass
 */
public class KeyInput implements KeyListener {

    @Override
    
    public void keyPressed(KeyEvent ke) {
        
 
            
//            EventListener.x_dir=0;
//            
//            EventListener.y_dir=.1f;
//        }
//             if (ke.getKeyCode()==KeyEvent.VK_UP){
//            EventListener.dir2+=.5;
//        }
//        if (ke.getKeyCode()==KeyEvent.VK_DOWN){
//            EventListener.dir2-=.5;
//        }
//        if (ke.getKeyCode()==KeyEvent.VK_LEFT){
//            EventListener.dir1-=.5;
//        }
//        if (ke.getKeyCode()==KeyEvent.VK_RIGHT){
//            EventListener.dir1+=.5;

    if (ke.getKeyCode()==KeyEvent.VK_LEFT){
         
        EventListener.dir1 -= 10;
        EventListener.apprx1 -= 10;
        EventListener.apprx2 -= 10;
        }
    if (ke.getKeyCode()==KeyEvent.VK_RIGHT){
         
        EventListener.dir1 += 10;
        EventListener.apprx1 += 10;
        EventListener.apprx2 += 10;
        }
      }
 
   
               
              
    
    @Override
    public void keyReleased(KeyEvent ke) {
      //  throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
